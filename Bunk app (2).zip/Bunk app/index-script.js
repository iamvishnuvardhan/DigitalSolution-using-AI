function redirectToBunkingPage() {
  window.location.href = "bunking.html";
}
